package com.eventsystem.security;

import com.eventsystem.model.User;
import com.eventsystem.repository.UserRepository;
import jakarta.servlet.FilterChain;
import jakarta.servlet.ServletException;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import org.springframework.web.filter.OncePerRequestFilter;

import java.io.IOException;

@Component
public class JwtFilter extends OncePerRequestFilter {

    @Autowired
    private UserRepository userRepository;

    @Override
    protected void doFilterInternal(
            HttpServletRequest request,
            HttpServletResponse response,
            FilterChain filterChain)

            throws ServletException, IOException {

        String header=
                request.getHeader(
                        "Authorization"
                );

        if(header!=null &&
                header.startsWith("Bearer ")){

            String token=
                    header.substring(7);

            String email=
                    JwtUtil.getEmail(token);

            User user=
                    userRepository
                            .findByEmail(email);

            request.setAttribute(
                    "loggedUser",
                    user
            );
        }

        filterChain.doFilter(
                request,
                response
        );
    }
}