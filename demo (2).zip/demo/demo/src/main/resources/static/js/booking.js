function parseJwt(token){

return JSON.parse(
atob(
token.split('.')[1]
)
);

}


async function bookTicket(){

let quantity=
document.getElementById(
"quantity"
).value;


let params=
new URLSearchParams(
window.location.search
);

let eventId=
params.get("id");


let token=
localStorage.getItem(
"token"
);

if(!token){

alert(
"Please Login First"
);

window.location=
"/login.html";

return;
}


let decoded=
parseJwt(token);

let email=
decoded.sub;


let userResponse=
await fetch(
`/users/email/${email}`
);

let user=
await userResponse.json();

let userId=
user.id;


let response=
await fetch(
`/booking/${userId}/${eventId}/${quantity}`,
{

method:"POST",

headers:{

Authorization:
"Bearer "+token

}

});

let data=
await response.text();

alert(data);

window.location="/";

}