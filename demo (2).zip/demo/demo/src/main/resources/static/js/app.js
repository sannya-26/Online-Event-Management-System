fetch("http://localhost:8080/events")

.then(res=>res.json())

.then(data=>{

let events=document
.getElementById("events");

data.forEach(event=>{

events.innerHTML+=`

<div class="col-md-4">

<div class="card p-3 mb-4">

<h4>${event.title}</h4>

<p>
Price :
₹${event.ticketPrice}
</p>

<p>
Remaining :
${event.remainingTickets}
</p>

<a href=
"booking.html?id=${event.id}"

class=
"btn btn-primary">

Book Now

</a>

</div>

</div>

`;

})

})