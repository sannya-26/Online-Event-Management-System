async function register(){

let user={

name:
document.getElementById(
"name"
).value,

email:
document.getElementById(
"email"
).value,

password:
document.getElementById(
"password"
).value,

role:
document.getElementById(
"role"
).value

};

let response=
await fetch(
"/users/register",
{

method:"POST",

headers:{
"Content-Type":
"application/json"
},

body:
JSON.stringify(user)

});

alert(
"Registration Successful"
);

window.location=
"/login.html";

}