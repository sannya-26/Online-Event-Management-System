function parseJwt(token){

return JSON.parse(
atob(
token.split('.')[1]
));

}

async function loadDashboard(){

let token=
localStorage.getItem(
"token"
);

let decoded=
parseJwt(token);

let email=
decoded.sub;


let response=
await fetch(
`/users/email/${email}`
);

let user=
await response.json();


let eventResponse=
await fetch(
`/events/organizer/${user.id}`
);

let events=
await eventResponse.json();

let div=
document.getElementById(
"events"
);


events.forEach(e=>{

div.innerHTML+=`

<div class=
"card p-3 mb-3">

<h3>

${e.title}

</h3>

<p>
Revenue: \u20B9${e.revenue}
</p>

<p>

Tickets Sold:
${e.soldTickets}

</p>

</div>

`;

});

}

loadDashboard();