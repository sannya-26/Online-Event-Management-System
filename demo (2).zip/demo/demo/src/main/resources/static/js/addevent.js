function parseJwt(token){

return JSON.parse(
atob(token.split('.')[1])
);

}

async function addEvent(){

let token=
localStorage.getItem("token");

if(!token){

alert("Please Login First");

window.location="/login.html";

return;
}

let email=
parseJwt(token).sub;


let userResponse=
await fetch(
`/users/email/${email}`
);

let user=
await userResponse.json();


let event={

title:
document.getElementById(
"title"
).value,

description:
document.getElementById(
"description"
).value,

location:
document.getElementById(
"location"
).value,

eventDate:
document.getElementById(
"eventDate"
).value,

ticketPrice:
parseFloat(
document.getElementById(
"ticketPrice"
).value
),

totalTickets:
parseInt(
document.getElementById(
"totalTickets"
).value
)

};


let response=
await fetch(
`/events/${user.id}`,
{

method:"POST",

headers:{

"Content-Type":
"application/json"

},

body:
JSON.stringify(event)

});

let data=
await response.text();

console.log(data);

if(response.ok){

alert(
"Event Created Successfully"
);

window.location=
"/dashboard.html";

}
else{

alert(data);

}

}