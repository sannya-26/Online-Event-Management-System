async function login(){

let email=
document.getElementById("email").value;

let password=
document.getElementById("password").value;


let response=
await fetch(
`http://localhost:8080/users/login?email=${email}&password=${password}`,
{
method:"POST"
}
);

let token=
await response.text();

localStorage
.setItem(
"token",
token
);

alert(
"Login Successful"
);

window.location=
"/";

}