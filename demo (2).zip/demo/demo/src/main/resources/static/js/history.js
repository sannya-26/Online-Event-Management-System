function parseJwt(token){

return JSON.parse(
atob(
token.split('.')[1]
)
);

}

async function loadHistory(){

let token=
localStorage.getItem(
"token"
);

let decoded=
parseJwt(token);

let email=
decoded.sub;


let response=
await fetch(
`/users/email/${email}`
);

let user=
await response.json();


let bookingResponse=
await fetch(
`/booking/history/${user.id}`
);

let bookings=
await bookingResponse.json();


let div=
document.getElementById(
"bookings"
);


bookings.forEach(b=>{

div.innerHTML+=`

<div class="card p-3 mb-3">

<h4>
${b.event.title}
</h4>

<p>
Tickets :
${b.quantity}
</p>

<p>
Location :
${b.event.location}
</p>

</div>

`;

});

}

loadHistory();